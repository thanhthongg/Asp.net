﻿if (cofirm("Cảm ơn bạn đã đăng ký Email theo dõi ♥!")) {
    txt = "You pressed OK!";
} else {

    txt = "You pressed Cancel!"
}