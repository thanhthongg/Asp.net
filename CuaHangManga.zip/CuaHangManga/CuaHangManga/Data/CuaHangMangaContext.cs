﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using CuaHangManga.Models;

namespace CuaHangManga.Data
{
    public class CuaHangMangaContext : DbContext
    {
        public CuaHangMangaContext (DbContextOptions<CuaHangMangaContext> options)
            : base(options)
        {
        }

        public DbSet<CuaHangManga.Models.Manga> Manga { get; set; }
    }
}
