﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using CuaHangManga.Data;
using System;
using System.Linq;
namespace CuaHangManga.Models
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new CuaHangMangaContext(
            serviceProvider.GetRequiredService<
            DbContextOptions<CuaHangMangaContext>>()))
            {
                // Kiểm tra thông tin cuốn sách đã tồn tại hay chưa
                if (context.Manga.Any())
                {
                    return; // Không thêm nếu cuốn sách đã tồn tại trong DB
                }
                context.Manga.AddRange(
                new Manga
                {
                    TenManga = "Conan",
                    NgayBanManga = DateTime.Parse("2018-10-16"),
                    TheLoaiManga = "Trinh thám, kinh dị.",
                    TacGiaManga = ".",
                    GiaManga = 11.98M,
                    DanhGia = "5*"
                },
                new Manga
                {
                    TenManga = "Dragon ball ",
                    NgayBanManga = DateTime.Parse("2021-8-3"),
                    TheLoaiManga = "Siêu nhiên, phiêu lưu ",
                    TacGiaManga = "1",
                    GiaManga = 18.59M,
                    DanhGia = "5*"
                }
                );
                context.SaveChanges();//lưu dữ liệu
            }
        }
    }
}