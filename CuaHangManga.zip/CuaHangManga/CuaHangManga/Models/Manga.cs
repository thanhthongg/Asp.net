﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
namespace CuaHangManga.Models
{
    public class Manga
    {
        public int Id { get; set; }
        [Display(Name = "Tên Manga ")]
        [StringLength(60, MinimumLength = 3)]
        [Required]
        public string TenManga { get; set; }
        [Display(Name = "Ngày bán ")]
        [DataType(DataType.Date)]
        public DateTime NgayBanManga { get; set; }
        [Display(Name = "Thể loại Manga ")]


     /* [RegularExpression(@"^[A-Z]+[a-zA-Z\s]*$")]
        [Required]
        [StringLength(30)] 
     */

        public string TheLoaiManga { get; set; }
        [Display(Name = "Tên tác giả ")]
        public string TacGiaManga { get; set; }
        [Display(Name = "Giá tiền ")]
        [Range(1, 100)]
        [DataType(DataType.Currency)]
        [Column(TypeName = "decimal(18, 2)")]
        public decimal GiaManga { get; set; }
        [Display(Name = "Đánh giá  ")]

        /*
               [RegularExpression(@"^[A-Z]+[a-zA-Z0-9""'\s-]*$")]
               [StringLength(5)]
               [Required]
       */

        public string DanhGia { get; set; }
    }
}