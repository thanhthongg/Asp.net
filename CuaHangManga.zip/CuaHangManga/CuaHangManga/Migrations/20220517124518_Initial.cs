﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace CuaHangManga.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Manga",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TenManga = table.Column<string>(nullable: true),
                    NgayBanManga = table.Column<DateTime>(nullable: false),
                    TheLoaiManga = table.Column<string>(nullable: true),
                    TacGiaManga = table.Column<string>(nullable: true),
                    GiaManga = table.Column<decimal>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Manga", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Manga");
        }
    }
}
